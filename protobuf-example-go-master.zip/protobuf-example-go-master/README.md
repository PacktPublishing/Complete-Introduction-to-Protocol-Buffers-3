# Protocol Buffers Example in Golang

This is a companion repository for my [Protocol Buffers course](http://bit.ly/protocol-buffers-github)

[![course logo](https://i.imgur.com/8fFmWAV.png)](http://bit.ly/protocol-buffers-github)

# Content

- Sample Code
- Few .proto files
- Read / Write to File
- JSON example